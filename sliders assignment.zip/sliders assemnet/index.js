function savefun()
{  
   alert("values succesfully stored to databse !!! " );
}
function cancelfun()
{
    alert("please select the values from the slider !!! ")
}
